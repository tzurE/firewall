
#include <linux/module.h> /* Needed by all modules */
#include <linux/kernel.h> /* Needed for KERN_INFO */ 
#include <linux/netfilter.h>
#include <linux/netfilter_ipv4.h> 
#include <linux/fs.h>
#include <linux/device.h>